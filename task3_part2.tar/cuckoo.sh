#!/bin/bash
set -u
# ./cuckoo.sh --pishitesuda=/abs/path/to/fifo
PIPE=""
for arg in "$@"; do
case "$arg" in
--pishitesuda=*) PIPE="${arg#*=}" ;;
esac
done
if [[ -z "${PIPE}" ]]; then
echo "Usage: $0 --pishitesuda=/abs/path/to/fifo" >&2
exit 1
fi
if [[ "${PIPE}" != /* ]]; then
echo "ERROR: FIFO path must be absolute: ${PIPE}" >&2
exit 1
fi
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="${BASE_DIR}/cuckoo.log"
cleanup() {
echo "$(date '+%F %T') Shutdown!" >> "${LOG}"
rm -f "${PIPE}"
exit 0
}
trap cleanup TERM
mkdir -p "$(dirname "${PIPE}")"
if [[ -e "${PIPE}" && ! -p "${PIPE}" ]]; then
echo "ERROR: ${PIPE} exists and is not a FIFO" >&2
exit 1
fi
if [[ ! -p "${PIPE}" ]]; then
mkfifo "${PIPE}"
fi
echo "$(date '+%F %T') Startup!" >> "${LOG}"
while true; do
if IFS= read -r line < "${PIPE}"; then
if [[ "${line}" =~ ^([A-Za-z0-9._-]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
name="${BASH_REMATCH[1]}"
pid="${BASH_REMATCH[2]}"
n=$((RANDOM % 9 + 2)) 
echo "$(date '+%F %T') ${name}[${pid}] ${n}" >> "${LOG}"
printf '%s\n' "${n}" > "${PIPE}"
else
  echo "$(date '+%F %T') UNKNOWN_REQUEST ${line}" >> "${LOG}"
fi
fi
done
