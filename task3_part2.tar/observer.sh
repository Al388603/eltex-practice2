#!/bin/bash
set -u
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF="${BASE_DIR}/observer.conf"
LOG="${BASE_DIR}/observer.log"
ts(){ date '+%F %T'; }
if [[ ! -f "${CONF}" ]]; then
echo "$(ts) ERROR: no config ${CONF}" >> "${LOG}"
exit 1
fi
is_running() {
local target="$1"
local p
for p in /proc/[0-9]*; do
[[ -r "${p}/cmdline" ]] || continue
if tr '\0' ' ' < "${p}/cmdline" 2>/dev/null | grep -Fq -- "${target}"; then
return 0
fi
done
return 1
}
while IFS= read -r task; do
[[ -z "${task}" ]] && continue
[[ "${task}" =~ ^# ]] && continue
if [[ ! -e "${task}" ]]; then
echo "$(ts) MISSING ${task}" >> "${LOG}"
continue
fi
if is_running "${task}"; then
: # уже запущен
else
nohup "${task}" >/dev/null 2>&1 &
echo "$(ts) RESTART ${task} newpid=$!" >> "${LOG}"
fi
done < "${CONF}"
