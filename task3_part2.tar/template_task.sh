#!/bin/bash
set -u
self="$(basename "$0")"
if [[ "$self" == "template_task.sh" ]]; then
echo "я бригадир, сам не работаю"
exit 0
fi
report="report_${self}.log"
ts() { date '+%F %T'; }
echo "$(ts) [$$] Скрипт запущен" >> "$report"
PIPE="/home/user1/task3_part2/cuckoo.pipe"
LOCK="${PIPE}.lock"
N="$(
 ( flock -x 200
printf '%s[%d]: how much time do I have?\n' "$self" "$$" > "$PIPE"
read -r ans < "$PIPE"
printf '%s' "$ans"
) 200>"$LOCK"
)"
if ! [[ "$N" =~ ^[0-9]+$ ]]; then
N=2
fi
sleep "$N"
echo "$(ts) [$$] Скрипт завершился, работал ${N} секунд." >> "$report"
